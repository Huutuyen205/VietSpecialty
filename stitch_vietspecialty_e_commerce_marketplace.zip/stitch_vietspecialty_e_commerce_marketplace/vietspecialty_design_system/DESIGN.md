---
name: VietSpecialty Design System
colors:
  surface: '#f0fdf3'
  surface-dim: '#d0ddd4'
  surface-bright: '#f0fdf3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eaf7ed'
  surface-container: '#e4f1e7'
  surface-container-high: '#dfebe2'
  surface-container-highest: '#d9e6dc'
  on-surface: '#131e18'
  on-surface-variant: '#3f4940'
  inverse-surface: '#28332d'
  inverse-on-surface: '#e7f4ea'
  outline: '#6f7a6f'
  outline-variant: '#becabd'
  surface-tint: '#006d36'
  primary: '#006b36'
  on-primary: '#ffffff'
  primary-container: '#23864a'
  on-primary-container: '#fcfff8'
  inverse-primary: '#7cda95'
  secondary: '#7d5800'
  on-secondary: '#ffffff'
  secondary-container: '#fdbf47'
  on-secondary-container: '#704e00'
  tertiary: '#a8351b'
  on-tertiary: '#ffffff'
  tertiary-container: '#c94d31'
  on-tertiary-container: '#fffeff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#97f7af'
  primary-fixed-dim: '#7cda95'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005228'
  secondary-fixed: '#ffdea9'
  secondary-fixed-dim: '#fabc45'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5f4100'
  tertiary-fixed: '#ffdad2'
  tertiary-fixed-dim: '#ffb4a3'
  on-tertiary-fixed: '#3d0600'
  on-tertiary-fixed-variant: '#891e06'
  background: '#f0fdf3'
  on-background: '#131e18'
  surface-variant: '#d9e6dc'
typography:
  display-hero:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 46px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 38px
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  title-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  badge-caption:
    fontFamily: Be Vietnam Pro
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
---

## Brand & Style

Hệ thống thiết kế này được xây dựng dành cho nền tảng thương mại điện tử đặc sản bản địa và thủ công truyền thống Việt Nam tích hợp trí tuệ nhân tạo (AI Assistant). Triết lý cốt lõi kết hợp giữa **Văn hóa thủ công mộc mạc (Artisanal Heritage)** và **Thương mại điện tử hiện đại, tinh gọn (Modern Functional Commerce)**.

### Định vị & Cảm xúc thương hiệu
- **Ấm cúng & Gần gũi:** Tái hiện không khí chợ quê, chõng tre, gian bếp gia đình và câu chuyện của người làm nghề bản xứ.
- **Tôn vinh cội nguồn:** Đề cao giá trị nguyên bản, chỉ dẫn địa lý và tâm huyết của nghệ nhân từ 4 tiểu vùng văn hóa: Bắc Bộ, Trung Bộ, Tây Nguyên và Nam Bộ.
- **Tin cậy & Minh bạch:** Đảm bảo xuất xứ hàng hóa, chất lượng kiểm định hữu cơ, OCOP và cam kết công bằng cho nông hộ.
- **Thông minh & Thấu cảm:** Trợ lý AI đồng hành đóng vai trò như một người sành ăn, am hiểu tường tận văn hóa ẩm thực từng vùng miền, gợi ý chuẩn xác theo khẩu vị và mùa vụ.

### Phong cách thiết kế (Design Style)
- Hòa quyện giữa **Minimalism hữu cơ (Organic Warm Minimalism)** và **Tactile/Editorial**:
  - Không gian thoáng đãng, nền kem dịu mắt thay cho nền xám lạnh công nghiệp.
  - Sử dụng đường nét mảnh dẻ, viền màu sợi cói mềm mại (#E8E2D6).
  - Tương phản thị giác nhẹ nhàng, tạo cảm giác như lật mở từng trang cẩm nang ẩm thực cao cấp.

## Colors

Hệ màu chỉ áp dụng chế độ Sáng (`light`), lấy cảm hứng từ thiên nhiên nhiệt đới trù phú, màu đất bazan, lá chè non và màu mật ong hoa cà phê.

### Hệ màu nền tảng & Bề mặt
- **Canvas Base (`#FFFCF5`):** Nền kem ấm tự nhiên, bảo vệ mắt và tạo cảm giác thân thuộc như giấy dó truyền thống.
- **Surface Pure (`#FFFFFF`):** Dành riêng cho thẻ sản phẩm, hộp thoại AI nổi bật, và module thanh toán.
- **Surface Muted / Warm Layer (`#F7F3EA`):** Nền phụ cho các khu vực lọc sản phẩm, thẻ thông tin phụ trợ hoặc bảng thông số chứng nhận OCOP.
- **Border Surface (`#E8E2D6`):** Viền tinh giản tạo cấu trúc ngăn nắp nhưng mềm mại.

### Hệ màu thương hiệu & Chức năng
- **Primary Green (`#23864A`):** Tượng trưng cho nông sản sạch, sức sống ruộng đồng và niềm tin.
  - *Hover State:* `#1C6B3C`
  - *Brand Heading / Deep Accents:* `#1C6B3C`
  - *Soft Container Tint:* `#EEF8F0`
  - *Soft Border Tint:* `#BFDFC9`
- **Secondary Honey (`#F4B740`):** Sắc vàng mật ong rừng, đại diện cho vụ mùa bội thu, điểm thưởng và sự trợ giúp tích cực từ AI.
- **Accent Terracotta (`#D9583B`):** Sắc gốm nung Bát Tràng / gạch đất nung, dùng cho nhãn giảm giá, ưu đãi giới hạn, cảnh báo số lượng tồn kho.

### Hệ màu định danh 4 Vùng miền (Regional Identifiers)
Được sử dụng độc quyền cho nhãn nguồn gốc, huy hiệu vùng miền và đường chỉ dẫn xuất xứ sản phẩm:
- **Bắc Bộ (`#0F9D8A` - Vải thiều, Chè Thái Nguyên, Cốm làng Vòng):** Xanh ngọc bích non nước Tràng An và đồi chè Tân Cương.
- **Trung Bộ (`#E9A21F` - Mè xửng Huế, Tỏi Lý Sơn, Yến sào Khánh Hòa):** Vàng cát miền Trung, nắng gió và kiến trúc cố đô.
- **Tây Nguyên (`#8B5E3C` - Cà phê Buôn Ma Thuột, Tiêu Chư Sê, Mật ong hoa cà phê):** Nâu đất đỏ bazan màu mỡ và hạt cà phê chín mọng.
- **Nam Bộ (`#E8704A` - Nước mắm Phú Quốc, Bánh pía Sóc Trăng, Xoài cát Hòa Lộc):** Cam san hô phù sa Cửu Long và vị ngọt trái cây nhiệt đới.

### Văn bản & Chữ
- **Text Main (`#1F2A24`):** Xanh rêu đen than thẫm, giàu tương phản nhưng mềm hơn màu đen tuyền `#000000`.
- **Text Muted / Secondary (`#5B6660`):** Màu xám tro thảo mộc, giữ vững độ tương phản chuẩn WCAG AAA trên nền kem.

## Typography

Kiến trúc phông chữ được thiết kế chuyên biệt để nâng niu vẻ đẹp của Tiếng Việt, giữ sự tôn nghiêm, trầm mặc trong tiêu đề nhưng cực kỳ mạch lạc, dễ đọc trên giao diện thương mại điện tử.

### Cặp phông tương phản (Serif & Sans)
- **Tiêu đề (Serif - Noto Serif):** Mang đường nét văn hiến, phảng phất vẻ hoài cổ của ấn phẩm mộc bản, dùng cho tiêu đề chính, thông điệp truyền cảm hứng và lời chào từ nghệ nhân.
- **Nội dung & Thao tác (Sans-serif - Be Vietnam Pro):** Được tạo ra dành riêng cho tiếng Việt với các dấu thanh được tối ưu chuẩn mực, không bao giờ bị đè dấu hay lỗi dòng, đảm bảo đọc lướt nhanh giá trị đơn hàng, chỉ số OCOP và thành phần dinh dưỡng.

### Hướng dẫn ứng dụng
- Tuyệt đối không dùng chữ viết hoa (ALL CAPS) cho các đoạn văn bản dài hoặc tiêu đề bài viết; chỉ sử dụng chữ hoa cho `badge-caption` phân loại xuất xứ và mã giảm giá ngắn.
- Các tiêu đề từ 26px trở lên luôn dùng phông Serif với màu Deep Green `#1C6B3C` hoặc `#1F2A24` để duy trì bản sắc.

## Layout & Spacing

Hệ thống vận hành trên cơ chế lưới chất lỏng linh hoạt (Fluid Grid System) dựa trên nhịp 8px tiêu chuẩn, duy trì cảm giác thông thoáng, giàu thẩm mỹ biên tập (editorial layout).

### Cấu trúc lưới theo thiết bị
- **Mobile (< 768px):** 4 cột, `gutter` 16px (1rem), `margin` viền ngoài 16px (1rem). Các thẻ sản phẩm hiển thị dạng lưới 2 cột hoặc danh sách cuộn dọc đơn nhất.
- **Tablet (768px - 1024px):** 8 cột, `gutter` 24px (1.5rem), `margin` viền ngoài 32px (2rem). Lưới sản phẩm hiển thị 3 cột.
- **Desktop (> 1024px):** 12 cột, chiều rộng nội dung tối đa `max-width: 1280px`, căn giữa màn hình, `gutter` 24px (1.5rem), `margin` biên 48px (3rem). Lưới sản phẩm chuẩn 4 cột.

### Nhịp điệu không gian
- Giữa các module nội dung lớn (ví dụ: từ Banner Khám phá xuống Danh sách Đặc sản Vùng miền) sử dụng khoảng cách `space-2xl` (48px) hoặc `space-3xl` (72px) để tạo khoảng nghỉ thị giác.
- Khoảng cách giữa các phần tử liên đới trong thẻ (hình ảnh -> tên sản phẩm -> giá) tuân thủ tỉ lệ từ `space-xs` (4px) đến `space-md` (16px).

## Elevation & Depth

Thay vì dùng hiệu ứng bóng xám thô ráp thông thường, hệ thống sử dụng **đổ bóng hữu cơ ngả sắc đất rêu (organic earthy shadows)** kết hợp với viền sợi tự nhiên để tạo độ sâu thanh lịch, ấm cúng.

### Cấp độ đổ bóng (Shadow Elevations)
- **Tầng 0 (Phẳng - Flat):** Nền chính `#FFFCF5` và các khối phụ `#F7F3EA`, không sử dụng bóng đổ, phân cách bằng đường viền `1px solid #E8E2D6`.
- **Tầng 1 (Thẻ trạng thái tĩnh - Card Surface):**
  - Bóng: `0 8px 24px rgba(31, 42, 36, 0.06)`
  - Viền mỏng: `1px solid #E8E2D6`
  - Áp dụng: Thẻ sản phẩm, thẻ bài viết làng nghề, bảng tóm tắt đơn hàng.
- **Tầng 2 (Tương tác Hover & Menu nổi):**
  - Bóng: `0 14px 32px rgba(31, 42, 36, 0.12)`
  - Dịch chuyển nhẹ: `-2px` trên trục Y.
  - Áp dụng: Thẻ khi rê chuột, dropdown danh mục, bộ lọc mở rộng.
- **Tầng 3 (Cửa sổ Trợ lý AI & Modal tương tác):**
  - Nền: `#FFFFFF` kết hợp viền kép siêu nhẹ hoặc viền điểm xuyết `#BFDFC9`.
  - Bóng: `0 20px 48px rgba(31, 42, 36, 0.16)`
  - Áp dụng: Hộp thoại AI Tư vấn mua sắm, Giỏ hàng trượt từ mép (Cart Drawer), Cửa sổ phóng to chứng chỉ xuất xứ.

## Shapes

Hệ thống hình khối thể hiện sự tròn trịa, đong đầy của hạt ngọc trời và sản vật địa phương, tránh sự gai góc cơ khí nhưng vẫn giữ sự chỉn chu hiện đại.

### Quy định bán kính bo góc (Corner Radii)
- **Thẻ sản phẩm, Thẻ bài viết & Module lớn (`rounded-lg`):** `14px` (`0.875rem`). Tạo cảm giác nâng niu, đóng khung câu chuyện đặc sản một cách trang nhã.
- **Thành phần tương tác (`rounded`):** `10px` (`0.625rem`). Dành cho nút bấm (Button), ô nhập liệu (Input field), ô chọn số lượng và menu lựa chọn.
- **Huy hiệu & Nhãn nhận diện (`rounded-full`):** `999px` (`rounded-pill`). Dành riêng cho huy hiệu Vùng miền (Bắc/Trung/Tây Nguyên/Nam), tem chứng nhận OCOP 4 sao / 5 sao, tag phân loại sản phẩm và avatar người bán.
- **Hộp thoại Trợ lý AI:** Góc bo `18px` cho toàn khung, riêng các bong bóng tin nhắn (Chat Bubbles) có bo góc `14px` với một góc nhọn `4px` phía bên người gửi để định vị hướng đối thoại tự nhiên.

## Components

Hướng dẫn hiện thực hóa các thành phần giao diện chuẩn mực, đồng nhất cho VietSpecialty:

### 1. Nút bấm (Buttons)
- **Nút chính (Primary Action):** Nền `#23864A`, chữ trắng `#FFFFFF`, bo góc `10px`, chiều cao 44px (mobile) / 48px (desktop). Hiệu ứng hover chuyển sang `#1C6B3C`. Dùng cho: "Chọn mua", "Đặt hàng ngay", "Hỏi AI về món này".
- **Nút phụ (Secondary / Outline):** Nền trong suốt hoặc `#EEF8F0`, viền `1.5px solid #23864A`, chữ `#23864A`. Khi hover, nền đổi sang `#BFDFC9` ở độ mờ 30%.
- **Nút AI tương tác nhanh (AI Action Pill):** Nền `#F7F3EA`, viền `1px solid #F4B740`, chữ `#1F2A24`, tiền tố icon ngôi sao/búp lúa màu vàng mật ong `#F4B740`. Bo tròn `999px`. Ví dụ: "Tìm quà biếu Tết dưới 500k", "Đặc sản chuẩn vị Bắc".

### 2. Thẻ sản phẩm (Product Card)
- Nền trắng tinh khôi `#FFFFFF`, bo góc `14px`, viền `#E8E2D6`.
- Ảnh sản phẩm tỉ lệ vuông `1:1` với xử lý góc bo trên mượt mà, chụp tự nhiên trên nền thớt gỗ, mâm tre hoặc quang cảnh xưởng chế biến.
- Huy hiệu vùng miền đính ở góc trên bên trái dạng `rounded-full`, ví dụ:
  - Nền `#EEF8F0`, chữ `#0F9D8A`: *"Bắc Bộ • Tân Cương"*
  - Nền mờ `#FFF6E6`, chữ `#E9A21F`: *"Trung Bộ • Cố Đô"*
  - Nền mờ `#F7F0EB`, chữ `#8B5E3C`: *"Tây Nguyên • Cư M'gar"*
  - Nền mờ `#FDF0EB`, chữ `#E8704A`: *"Nam Bộ • Phú Quốc"*
- Giá sản phẩm dùng màu `#1C6B3C` đậm nét với kiểu chữ `title-md`, giá gạch bỏ dùng `#5B6660` dạng `body-sm`.
- Nút thêm nhanh vào giỏ tròn `40px` ở góc dưới thẻ, biểu tượng giỏ đan truyền thống tối giản.

### 3. Hộp thoại Trợ lý AI Mua sắm (AI Concierge Widget)
- Nằm cố định ở góc dưới bên phải màn hình (cách mép 24px).
- Nút kích hoạt: Tròn `56px`, nền gradient nhẹ giữa `#23864A` và `#1C6B3C`, viền chỉ vàng `#F4B740`, đổ bóng tầng 3.
- Khung chat: Nền `#FFFCF5`, thanh tiêu đề mang phong cách cẩm nang trang trọng: *"Trợ lý Đặc sản Bản địa"*, đi kèm chỉ báo trực tuyến màu xanh ngọc.
- Khối gợi ý sản phẩm bên trong chat: Định dạng thẻ ngang nhỏ gọn (compact card) gồm ảnh thu nhỏ `64x64px`, tên đặc sản, cam kết nguồn gốc và nút "Thêm vào giỏ" tức thì.

### 4. Ô nhập liệu (Input Fields & Select)
- Chiều cao `44px`, nền `#FFFFFF`, viền `1px solid #E8E2D6`, bo góc `10px`.
- Khi trỏ chuột / Active: Viền chuyển sang màu xanh chủ đạo `#23864A`, đổ bóng mờ viền `0 0 0 3px rgba(35, 134, 74, 0.15)`.
- Nhãn nhãn trường (Label): `Be Vietnam Pro` 14px chữ đậm vừa (`#1F2A24`), gợi ý bên trong (Placeholder) màu `#5B6660`.

### 5. Checkbox & Radio Buttons
- Bo góc `4px` cho Checkbox và `50%` cho Radio.
- Kích thước chuẩn `20x20px`.
- Khi chưa kích hoạt: Nền `#FFFFFF`, viền `1.5px solid #E8E2D6`.
- Khi chọn: Nền lấp đầy `#23864A`, dấu kiểm màu trắng `#FFFFFF`, viền `#23864A`.

### 6. Thẻ câu chuyện nghệ nhân / Nông hộ (Storytelling Card)
- Bề mặt `#F7F3EA`, viền `#E8E2D6`.
- Ảnh chân dung nghệ nhân hoặc làng nghề tỉ lệ 16:9.
- Trích dẫn câu nói của nghệ nhân bằng phông `Noto Serif` nghiêng, trân trọng hành trình bảo tồn phương pháp ủ chượp nước mắm truyền thống hoặc sao chè thủ công.